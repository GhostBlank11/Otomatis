<?php 
include 'header.php';
?>
                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
                       
                    </div>

                    <!-- Content Row -->
                    <div class="row">

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Semua Transaksi</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?=$semua_trx?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Transaksi Sukses</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?=$trx_sukses?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-danger shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Transaksi Gagal
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?=$trx_gagal?></div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Pending Requests Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Transaksi Pending</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?=$trx_pending?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-comments fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Content Row -->

                   <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Data Transaksi</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Invoice</th>
                                            <th>Produk</th>
                                            <th>SKU Produk</th>
                                            <th>Nomor Pengisian</th>
                                            <th>Harga</th>
                                            <th>Status Pembayaran</th>
                                            <th>Status Pengiriman</th>
                                            <th>Whatsapp Customer</th>
                                            <th>Link Pembayaran</th>
                                            <th>Serial Number</th>
                                        </tr>
                                    </thead>
                                   <tbody>
                                       <?php
                                       $no = 1;
                                       while ($trx = mysqli_fetch_array($data_transaksi)){
                                           
                                           ?>
                                           <tr>
                                            <td><?=$no++?></td>
                                            <td><?=$trx['no_pembayaran']?></td>
                                            <td><?=$trx['produk']?></td>
                                            <td><?=$trx['sku_produk']?></td>
                                            <td><?=$trx['tujuan']?>(<?=$trx['server']?>)</td>
                                            <td>Rp. <?=$trx['harga']?></td>
                                            <td><?=$trx['status_pembayaran']?></td>
                                            <td><?=$trx['status_pengiriman']?></td>
                                            <td><?=$trx['no_wa']?></td>
                                            <td><?=$trx['link_pembayaran']?></td>
                                            <td><?=$trx['game']?></td>
                                       <?php }
                                       ?>
                                       </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->
            <script>
                var a = document.getElementById('dashboard');
                a.classList.add('active');
            </script>
<?php
include 'footer.php';
?>