<?php 
include 'header.php';

$id= $_GET['id'];
$detail_trx = mysqli_query($koneksi,"select * from transaksi where id = '$id'");
$list = mysqli_fetch_array($detail_trx);
?>
<!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Edit Transaksi</h1>
                        
                       
                    </div>

                    <!-- Content Row -->
                   

                    <!-- Content Row -->

                   <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <div class="row">
                                <div class="col">
                                    <h6 class="m-0 font-weight-bold text-primary">Edit Transaksi <?=$list['no_pembayaran']?></h6>
                                </div>
                              
                            </div>
                            
                        </div>
                        <div class="card-body">
                            <form method="post" action="api/edit_transaksi">
                           <div class="row">
                               <div class="col-12 col-md-6 mb-2">
                                   Nomor Invoice
                                   <input type="text" class="form-control"  value="<?=$list['no_pembayaran']?>" name="no_pembayaran">
                               </div>
                                <div class="col-12 col-md-6 mb-2">
                                   Nomor Pengisian
                                   <div class="row">
                                    <div class="col-12 col-md-6 mb-2">
                                   <input type="text" class="form-control"  value="<?=$list['tujuan']?>" name="tujuan">
                                   </div>
                                    <div class="col-12 col-md-6 mb-2">
                                   <input type="text" class="form-control"  value="<?=$list['server']?>" name="server" placeholder="Server">
                                   </div>
                                   </div>
                               </div>
                               <div class="col-12 col-md-6 mb-2">
                                   Produk
                                   <input type="text" class="form-control"  value="<?=$list['produk']?>" name="produk">
                               </div>
                               <div class="col-12 col-md-6 mb-2">
                                   Harga
                                   <input type="text" class="form-control"  value="<?=$list['harga']?>" name="harga">
                               </div>
                               
                                <div class="col-12 col-md-6 mb-2">
                                   Status Pembayaran
                                   <input type="text" class="form-control"  value="<?=$list['status_pembayaran']?>" name="status_pembayaran">
                               </div>
                                <div class="col-12 col-md-6 mb-2">
                                   Status Pengiriman
                                   <input type="text" class="form-control"  value="<?=$list['status_pengiriman']?>" name="status_pengiriman">
                               </div>
                               
                                <div class="col-12 col-md-6 mb-2">
                                   Link Pembayaran
                                   <input type="text" class="form-control"  value="<?=$list['link_pembayaran']?>" name="link_pembayaran">
                               </div>
                                <div class="col-12 col-md-6 mb-2">
                                   SKU Produk
                                   <input type="text" class="form-control"  value="<?=$list['sku_produk']?>" name="sku_produk">
                               </div>
                               
                                <div class="col-12 col-md-6 mb-2">
                                   Serial Number
                                   <input type="text" class="form-control"  value="<?=$list['game']?>" name="sn">
                               </div>
                               
                               <div class="col-12 col-md-6 mb-2">
                                   Nomor Whatsapp
                                   <input type="text" class="form-control"  value="<?=$list['no_wa']?>" name="wa">
                               </div>
                               <input type="hidden" name="id" value ="<?=$list['id']?>">
                               <div class="col">
                                   <button  class="btn btn-primary mb-2 mt-2"type="submit">Simpan</button>
                                
                                  </form>
                               </div>
                           </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            
            
            
            <!-- Ubah TRX Modal-->
    <div class="modal fade" id="pembayaran" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ubah Status Pembayaran</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="api/transaksi">
                    <select class="form-control" aria-label="Default select example" name="status">
                 <option selected value="all">Pilih Pembayaran</option>
                  <option value="UNPAID">Belum Lunas</option>
                  <option value="PAID">Dibayar</option>
                  <option value="REFAUND">Dikembalikan</option>
</select>
<input type="hidden" name="id" value="<?=$list['id']?>">
<input type="hidden" name="ket" value="bayar">
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" >Simpan</button>
                </form>
                </div>
            </div>
        </div>
    </div>

            
    <!-- Ubah Pengiriman Modal-->
    <div class="modal fade" id="pengiriman" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ubah Status Pengiriman</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="api/transaksi">
                    Status Pengiriman
                    <select class="form-control mb-2" aria-label="Default select example" name="status">
                 <option selected value="all">Pilih Pengiriman</option>
                  <option value="Pending">Pending</option>
                  <option value="Sukses">Sukses</option>
                  <option value="Gagal">Gagal</option>
</select>
Serial Number
<input type="text" class="form-control mb-2" name="sn">
 Kirim notifikasi ke User?
                    <select class="form-control" aria-label="Default select example" name="notif">
                 
                  <option value="Tidak">Tidak</option>
                  <option value="Ya">Ya</option>
                  
</select>
<input type="hidden" name="id" value="<?=$list['id']?>">
<input type="hidden" name="ket" value="kirim">
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" >Simpan</button>
                </form>
                </div>
            </div>
        </div>
    </div>        
            
            <!-- End of Main Content -->
            <script>
                var a = document.getElementById('transaksi');
                a.classList.add('active');
            </script>
<?php
include 'footer.php';
?>