<?php
include '../../koneksi.php';

$id=$_GET['id'];

$hapus = mysqli_query($koneksi,"delete from transaksi where id = '$id'");

if($hapus){
    header('location:../transaksi?status=Sukses');
    exit();
}else{
    header('location:../transaksi?status=Gagal');
    exit();
}