<?php
include '../../koneksi.php';
include '../../lib/solusimedia.php';

$id = $_POST['id'];
$no_pembayaran = $_POST['no_pembayaran'];
$tujuan = $_POST['tujuan'];
$server = $_POST['server'];
$produk = $_POST['produk'];
$harga = $_POST['harga'];
$status_pembayaran = $_POST['status_pembayaran'];
$status_pengiriman = $_POST['status_pengiriman'];
$link_pembayaran = $_POST['link_pembayaran'];
$sku_produk = $_POST['sku_produk'];
$sn = $_POST['sn'];
$wa = $_POST['wa'];

$update = mysqli_query($koneksi,"update transaksi set no_pembayaran = '$no_pembayaran', tujuan = '$tujuan', server = '$server', harga = '$harga', status_pembayaran = '$status_pembayaran', status_pengiriman = '$status_pengiriman', no_wa = '$wa', game = '$sn', produk = '$produk',link_pembayaran = '$link_pembayaran', sku_produk = '$sku_produk' where id = '$id'");

if ($update){
    header('location:../edit_transaksi?status=Sukses&id='.$id);
    exit();
}else{
    header('location:../edit_transaksi?status=Gagal&id='.$id);
    exit();
}