<?php
include '../../koneksi.php';
include '../../lib/solusimedia.php';
$id = $_POST['id'];
$status = $_POST['status'];
$ket = $_POST['ket'];
$notif = $_POST['notif'];
$sn = $_POST['sn'];
if ($ket == "bayar"){
    $update = mysqli_query($koneksi,"update transaksi set status_pembayaran='$status' where id = '$id'");
    if($update){
        header('location:../detail_transaksi?status=Sukses&id='.$id);
        exit();
    }else{
        header('location:../detail_transaksi?status=Gagal&id='.$id);
        exit();
    }
}else{
    $update = mysqli_query($koneksi,"update transaksi set status_pengiriman='$status' , game = '$sn' where id = '$id'");
    if($update){
        if($notif == "Ya"){
            $data_trx = mysqli_query($koneksi,"select * from transaksi where id = '$id'");
            $data_trx = mysqli_fetch_array($data_trx);
            
            $cs = $data_setting['cs'];
$no_wa = $data_trx['no_wa'];
$invoice = $data_trx['no_pembayaran'];
$tujuan = $data_trx['tujuan'];
$server = $data_trx['server'];
$produk = $data_trx['produk'];
$serial = $data_trx['game'];
$datawa1 = [
    'api_key' => $data_setting['api_wa'],
    'sender' => $data_setting['sender'],
    'number' => $no_wa,
    'message' => 'Status Pengiriman '.PHP_EOL.PHP_EOL.'No. invoice : '.$invoice.PHP_EOL.'No Pengisian : '.$tujuan.'('.$server.')'.PHP_EOL.'Produk : '.$produk.PHP_EOL.'Status Pengiriman: '.$status.PHP_EOL.'SN : '.$serial.PHP_EOL.'Terimakasih!!!'.PHP_EOL.PHP_EOL.PHP_EOL.'Customer Service: '.$cs
    ];
    $curl = curl_init();
                                        
    curl_setopt_array($curl, array(
    CURLOPT_URL => $data_setting['url_api'],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => json_encode($datawa1),
    CURLOPT_HTTPHEADER => array(
    'Content-Type: application/json'
    ),
    ));
                            
    $response = curl_exec($curl);
                                                    
    curl_close($curl);
    
        }
        header('location:../detail_transaksi?status=Sukses&id='.$id);
        exit();
    }else{
        header('location:../detail_transaksi?status=Gagal&id='.$id);
        exit();
    }
}